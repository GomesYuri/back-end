
package br.edu.imepac.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import br.edu.imepac.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
}
