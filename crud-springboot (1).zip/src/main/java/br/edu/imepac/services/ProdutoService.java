
package br.edu.imepac.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import br.edu.imepac.entities.Produto;
import br.edu.imepac.repositories.ProdutoRepository;

import java.util.List;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    public List<Produto> listar() {
        return repository.findAll();
    }

    public Produto buscar(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Produto salvar(Produto produto) {
        return repository.save(produto);
    }

    public Produto atualizar(Long id, Produto novo) {
        Produto produto = buscar(id);
        if (produto != null) {
            produto.setNome(novo.getNome());
            produto.setPreco(novo.getPreco());
            return repository.save(produto);
        }
        return null;
    }

    public void deletar(Long id) {
        repository.deleteById(id);
    }
}
